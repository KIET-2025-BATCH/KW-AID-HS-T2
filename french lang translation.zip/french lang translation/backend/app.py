from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from transformers import MarianMTModel, MarianTokenizer

app = Flask(__name__, static_folder="static", template_folder="templates")
CORS(app)  # Enable CORS

# Load translation model (English to French)4
model_name = "Helsinki-NLP/opus-mt-en-fr"
tokenizer = MarianTokenizer.from_pretrained(model_name)
model = MarianMTModel.from_pretrained(model_name)

def translate_english_to_french(text):
    """Translates English text to French."""
    inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True)
    translated_tokens = model.generate(**inputs)
    translated_text = tokenizer.decode(translated_tokens[0], skip_special_tokens=True)
    return translated_text

# Serve the frontend
@app.route('/')
def home():
    return render_template("index.html")

# Translation API
@app.route('/translate', methods=['POST'])
def translate():
    data = request.get_json()
    
    if 'text' not in data or not data['text'].strip():
        return jsonify({"error": "No text provided"}), 400
    
    english_text = data['text'].strip()

    try:
        translated_text = translate_english_to_french(english_text)
        return jsonify({"english": english_text, "french": translated_text})
    except Exception as e:
        return jsonify({"error": f"Translation failed: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)



    
