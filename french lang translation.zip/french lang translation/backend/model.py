import torch
from transformers import MarianMTModel, MarianTokenizer

# Load the pre-trained model and tokenizer for English-to-French translation
from transformers import MarianMTModel, MarianTokenizer

model_name = "Helsinki-NLP/opus-mt-en-fr"
tokenizer = MarianTokenizer.from_pretrained(model_name, timeout=60)
model = MarianMTModel.from_pretrained(model_name, timeout=60)

def translate_english_to_french(text):
    """Translates an English sentence to French using MarianMT."""
    # Tokenize the input text
    inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True)

    # Check if a GPU is available, otherwise use CPU
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)
    inputs = {key: value.to(device) for key, value in inputs.items()}

    # Generate translation
    translated_tokens = model.generate(**inputs)

    # Decode translated text
    translated_text = tokenizer.decode(translated_tokens[0], skip_special_tokens=True)
    return translated_text

# User Input
if __name__ == "__main__":
    user_input = input("Enter a sentence in English: ")
    translated_sentence = translate_english_to_french(user_input)
    print(f"Translated sentence in French: {translated_sentence}")
    
