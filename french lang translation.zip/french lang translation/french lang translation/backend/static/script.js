function translateText() {
    const inputText = document.getElementById("inputText").value;
    const outputText = document.getElementById("outputText");
    const errorMessage = document.getElementById("errorMessage");

    if (inputText.trim() === "") {
        alert("Please enter text to translate.");
        return;
    }

    fetch("http://127.0.0.1:5000/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: inputText })
    })
    .then(response => response.json())
    .then(data => {
        if (data.french) {
            outputText.innerText = "French: " + data.french;
            errorMessage.innerText = ""; // Clear errors
        } else if (data.error) {
            errorMessage.innerText = data.error;
            outputText.innerText = ""; // Clear translation
        }
    })
    .catch(error => console.error("Error:", error));
}  